# Frontend - Minimal stub

This is a tiny static frontend that demonstrates calling backend endpoints. For a full Angular 16 project, replace this with an `ng new` app and implement components, services and guards as per the project spec.
To run:
- npm install
- npm start
Then open http://localhost:3000 (lite-server) and click Create Task.
