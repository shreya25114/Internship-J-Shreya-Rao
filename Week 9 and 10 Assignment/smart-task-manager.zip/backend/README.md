# Backend - Smart Task Manager (Spring Boot)

## How to run
- Requires JDK 17 and Maven.
- From backend/ run:
  mvn spring-boot:run

This is a starter skeleton with in-memory H2 DB. JWT, email verification, and password encoding are stubbed for brevity.
