package com.example.smart.controller;

import com.example.smart.model.Task;
import com.example.smart.repository.TaskRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    private final TaskRepository taskRepository;
    public TaskController(TaskRepository taskRepository){
        this.taskRepository = taskRepository;
    }

    @GetMapping
    public List<Task> all(){ return taskRepository.findAll(); }

    @PostMapping
    public Task create(@RequestBody Task task){ return taskRepository.save(task); }

    @GetMapping("/{id}")
    public ResponseEntity<Task> get(@PathVariable Long id){
        return taskRepository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Task> update(@PathVariable Long id, @RequestBody Task t){
        return taskRepository.findById(id).map(existing -> {
            existing.setTitle(t.getTitle());
            existing.setDescription(t.getDescription());
            existing.setDueDate(t.getDueDate());
            existing.setPriority(t.getPriority());
            existing.setStatus(t.getStatus());
            existing.setAssigneeIds(t.getAssigneeIds());
            taskRepository.save(existing);
            return ResponseEntity.ok(existing);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id){
        taskRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }
}
