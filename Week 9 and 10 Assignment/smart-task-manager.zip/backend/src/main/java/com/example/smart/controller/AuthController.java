package com.example.smart.controller;

import com.example.smart.model.User;
import com.example.smart.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserRepository userRepository;
    public AuthController(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user){
        if(userRepository.findByEmail(user.getEmail()).isPresent()){
            return ResponseEntity.badRequest().body(Map.of("message","Email already in use"));
        }
        // NOTE: password should be encoded in a real app
        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message","User registered. (Verify email in production)" ));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body){
        var opt = userRepository.findByEmail(body.get("email"));
        if(opt.isEmpty()) return ResponseEntity.status(401).body(Map.of("message","Invalid credentials"));
        var user = opt.get();
        if(!user.getPassword().equals(body.get("password"))) return ResponseEntity.status(401).body(Map.of("message","Invalid credentials"));
        // In production return JWT token
        return ResponseEntity.ok(Map.of("message","Logged in (stub)", "userId", user.getId()));
    }
}
