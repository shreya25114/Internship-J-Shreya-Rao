package com.example.smart.model;

public enum Role {
    ROLE_ADMIN, ROLE_MANAGER, ROLE_EMPLOYEE
}
