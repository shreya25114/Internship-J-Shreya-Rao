CREATE TABLE IF NOT EXISTS employee (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  department VARCHAR(255) NOT NULL,
  position VARCHAR(255) NOT NULL,
  salary DOUBLE
);

INSERT INTO employee(name, department, position, salary) VALUES ('Alice', 'Engineering', 'Developer', 90000);
INSERT INTO employee(name, department, position, salary) VALUES ('Bob', 'HR', 'Manager', 75000);
