package com.example.employeeservice.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * Employee entity - stored in SQL and used via JdbcTemplate.
 */
public class Employee {
    private Long id;
    @NotBlank private String name;
    @NotBlank private String department;
    @NotBlank private String position;
    @Min(0) private Double salary;

    // getters & setters
    public Long getId(){ return id; }
    public void setId(Long id){ this.id = id; }
    public String getName(){ return name; }
    public void setName(String n){ this.name = n; }
    public String getDepartment(){ return department; }
    public void setDepartment(String d){ this.department = d; }
    public String getPosition(){ return position; }
    public void setPosition(String p){ this.position = p; }
    public Double getSalary(){ return salary; }
    public void setSalary(Double s){ this.salary = s; }
}
