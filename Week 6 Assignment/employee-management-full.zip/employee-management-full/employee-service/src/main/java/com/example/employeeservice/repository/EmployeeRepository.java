package com.example.employeeservice.repository;

import com.example.employeeservice.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.util.List;
import java.util.Optional;

/**
 * JdbcTemplate-based repository for Employee.
 */
@Repository
public class EmployeeRepository {

    @Autowired private JdbcTemplate jdbc;

    private Employee mapRow(ResultSet rs, int rowNum) throws java.sql.SQLException {
        Employee e = new Employee();
        e.setId(rs.getLong("id"));
        e.setName(rs.getString("name"));
        e.setDepartment(rs.getString("department"));
        e.setPosition(rs.getString("position"));
        e.setSalary(rs.getDouble("salary"));
        return e;
    }

    public List<Employee> findAll() {
        return jdbc.query("SELECT * FROM employee", this::mapRow);
    }

    public Optional<Employee> findById(Long id) {
        List<Employee> list = jdbc.query("SELECT * FROM employee WHERE id = ?", new Object[]{id}, this::mapRow);
        return list.stream().findFirst();
    }

    public Employee save(Employee e) {
        if (e.getId() == null) {
            jdbc.update("INSERT INTO employee(name, department, position, salary) VALUES (?, ?, ?, ?)",
                    e.getName(), e.getDepartment(), e.getPosition(), e.getSalary());
            Long id = jdbc.queryForObject("SELECT MAX(id) FROM employee", Long.class);
            e.setId(id);
        } else {
            jdbc.update("UPDATE employee SET name=?, department=?, position=?, salary=? WHERE id=?",
                    e.getName(), e.getDepartment(), e.getPosition(), e.getSalary(), e.getId());
        }
        return e;
    }

    public boolean deleteById(Long id) {
        return jdbc.update("DELETE FROM employee WHERE id = ?", id) > 0;
    }
}
