package com.example.employeeservice.service;

import com.example.employeeservice.model.Employee;
import com.example.employeeservice.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Service layer for employees; demonstrates Java 8 Streams and Collections.
 */
@Service
public class EmployeeService {

    @Autowired private EmployeeRepository repo;

    public List<Employee> listAll() {
        return repo.findAll();
    }

    public Optional<Employee> getById(Long id) {
        return repo.findById(id);
    }

    public Employee create(Employee e) {
        return repo.save(e);
    }

    public Employee update(Long id, Employee e) {
        e.setId(id);
        return repo.save(e);
    }

    public boolean delete(Long id) {
        return repo.deleteById(id);
    }

    // Example: group by department
    public Map<String, List<Employee>> groupByDepartment() {
        return listAll().stream().collect(Collectors.groupingBy(Employee::getDepartment));
    }

    // Example: filter high salary > threshold
    public List<Employee> filterHighSalary(double threshold) {
        return listAll().stream().filter(emp -> emp.getSalary() != null && emp.getSalary() > threshold).collect(Collectors.toList());
    }
}
