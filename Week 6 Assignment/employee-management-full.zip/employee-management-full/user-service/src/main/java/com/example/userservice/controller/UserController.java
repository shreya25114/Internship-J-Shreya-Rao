package com.example.userservice.controller;

import com.example.userservice.dto.UserDTO;
import com.example.userservice.model.User;
import com.example.userservice.security.JwtUtil;
import com.example.userservice.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
/* imports */
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Controller exposing registration and login endpoints.
 */
@RestController
@RequestMapping("/users")
@Validated
public class UserController {

    private Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired private UserService userService;
    @Autowired private JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody UserDTO.Register dto) {
        logger.info("Register request for {}", dto.username);
        User user = new User();
        user.setUsername(dto.username);
        user.setPassword(dto.password);
        user.setEmail(dto.email);
        User created = userService.register(user);
        return ResponseEntity.ok(created);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody UserDTO.Login dto) {
        logger.info("Login attempt for {}", dto.username);
        return userService.findByUsername(dto.username)
                .map(u -> {
                    if (userService.checkPassword(dto.password, u.getPassword())) {
                        String token = jwtUtil.generateToken(u.getUsername());
                        return ResponseEntity.ok().body(java.util.Collections.singletonMap("token", token));
                    } else {
                        return ResponseEntity.status(401).body("Invalid credentials");
                    }
                }).orElse(ResponseEntity.status(404).body("User not found"));
    }

    @GetMapping("/profile")
    public ResponseEntity<?> profile(@RequestHeader("Authorization") String auth) {
        // simple extraction; token expected as "Bearer <token>"
        String token = auth.replace("Bearer ", "");
        String username = jwtUtil.extractUsername(token);
        return userService.findByUsername(username)
                .map(u -> ResponseEntity.ok(u))
                .orElse(ResponseEntity.status(404).body("User not found"));
    }
}
