package com.example.userservice.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

/**
 * DTOs for Register and Login
 */
public class UserDTO {
    public static class Register {
        @NotBlank public String username;
        @NotBlank public String password;
        @Email public String email;
    }
    public static class Login {
        @NotBlank public String username;
        @NotBlank public String password;
    }
}
