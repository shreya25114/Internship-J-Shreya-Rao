# Employee Management System - Full Starter (User + Employee Services)

This repository contains two Spring Boot microservices:

- **user-service** (port 8081): user registration, login, JWT generation (uses H2 for demo).
- **employee-service** (port 8082): employee CRUD via JdbcTemplate, protected by JWT (uses H2).

Run each service independently with Maven wrapper:
- `./mvnw clean spring-boot:run`

Endpoints:
- User Service (8081)
  - POST /users/register
  - POST /users/login
  - GET /users/profile (Authorization: Bearer <token>)
- Employee Service (8082) — all endpoints require Authorization header
  - GET /employees
  - GET /employees/{id}
  - POST /employees
  - PUT /employees/{id}
  - DELETE /employees/{id}

This is a starter project for the assignment. Expand for MySQL, Swagger, Docker, tests, and improved security.
