package com.example.sms.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class ConfigManager {
    private static final Properties props = new Properties();

    static {
        try (InputStream is = ConfigManager.class.getClassLoader().getResourceAsStream("application.properties")) {
            if (is != null) props.load(is);
            else throw new IllegalStateException("application.properties not found on classpath");
        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private ConfigManager() {}

    public static String get(String key) {
        return props.getProperty(key);
    }

    public static int getInt(String key, int defaultValue) {
        try { return Integer.parseInt(props.getProperty(key)); } catch (Exception e) { return defaultValue; }
    }
}
