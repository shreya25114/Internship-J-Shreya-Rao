package com.example.sms;

import com.example.sms.model.Student;
import com.example.sms.service.StudentService;
import com.example.sms.exception.DaoException;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Main {
    private static final StudentService service = new StudentService();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        printWelcome();
        while (true) {
            printMenu();
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1": create(sc); break;
                    case "2": listAll(); break;
                    case "3": findById(sc); break;
                    case "4": searchByName(sc); break;
                    case "5": update(sc); break;
                    case "6": delete(sc); break;
                    case "7": export(sc); break;
                    case "0": System.out.println("Goodbye"); sc.close(); return;
                    default: System.out.println("Unknown option");
                }
            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }
        }
    }

    private static void printWelcome() {
        System.out.println("=== Student Management System ===");
    }

    private static void printMenu() {
        System.out.println("\n1) Create student");
        System.out.println("2) List all students");
        System.out.println("3) Find student by id");
        System.out.println("4) Search by name");
        System.out.println("5) Update student");
        System.out.println("6) Delete student");
        System.out.println("7) Export to CSV");
        System.out.println("0) Exit");
        System.out.print("Choose: ");
    }

    private static void create(Scanner sc) throws DaoException {
        System.out.println("Enter first name:");
        String fn = sc.nextLine();
        System.out.println("Enter last name:");
        String ln = sc.nextLine();
        System.out.println("Enter email:");
        String email = sc.nextLine();
        System.out.println("Enter dob (YYYY-MM-DD) or blank:");
        String dob = sc.nextLine();
        System.out.println("Enter phone or blank:");
        String phone = sc.nextLine();
        System.out.println("Enter GPA or blank:");
        String gpaStr = sc.nextLine();
        Student s = new Student(fn, ln, email,
                dob.trim().isEmpty() ? null : LocalDate.parse(dob),
                phone.trim().isEmpty() ? null : phone,
                gpaStr.trim().isEmpty() ? null : Double.parseDouble(gpaStr));
        Student created = service.createStudent(s);
        System.out.println("Created: " + created);
    }

    private static void listAll() throws DaoException {
        List<Student> list = service.getAllStudents();
        list.forEach(System.out::println);
    }

    private static void findById(Scanner sc) throws DaoException {
        System.out.println("Enter id:");
        Long id = Long.parseLong(sc.nextLine());
        Optional<Student> s = service.getStudentById(id);
        System.out.println(s.orElse(null));
    }

    private static void searchByName(Scanner sc) throws DaoException {
        System.out.println("Enter search term:");
        String q = sc.nextLine();
        service.searchByName(q).forEach(System.out::println);
    }

    private static void update(Scanner sc) throws DaoException {
        System.out.println("Enter id to update:");
        Long id = Long.parseLong(sc.nextLine());
        Optional<Student> maybe = service.getStudentById(id);
        if (!maybe.isPresent()) { System.out.println("Not found"); return; }
        Student s = maybe.get();
        System.out.println("Leave blank to keep existing value.");
        System.out.printf("First name (%s):%n", s.getFirstName());
        String fn = sc.nextLine(); if (!fn.trim().isEmpty()) s.setFirstName(fn);
        System.out.printf("Last name (%s):%n", s.getLastName());
        String ln = sc.nextLine(); if (!ln.trim().isEmpty()) s.setLastName(ln);
        System.out.printf("Email (%s):%n", s.getEmail());
        String email = sc.nextLine(); if (!email.trim().isEmpty()) s.setEmail(email);
        System.out.printf("DOB (%s) YYYY-MM-DD:%n", s.getDob());
        String dob = sc.nextLine(); if (!dob.trim().isEmpty()) s.setDob(LocalDate.parse(dob));
        System.out.printf("Phone (%s):%n", s.getPhone());
        String phone = sc.nextLine(); if (!phone.trim().isEmpty()) s.setPhone(phone);
        System.out.printf("GPA (%s):%n", s.getGpa());
        String gpa = sc.nextLine(); if (!gpa.trim().isEmpty()) s.setGpa(Double.parseDouble(gpa));
        boolean ok = service.updateStudent(s);
        System.out.println("Updated: " + ok);
    }

    private static void delete(Scanner sc) throws DaoException {
        System.out.println("Enter id to delete:");
        Long id = Long.parseLong(sc.nextLine());
        boolean ok = service.deleteStudent(id);
        System.out.println("Deleted: " + ok);
    }

    private static void export(Scanner sc) throws DaoException {
        String path = com.example.sms.util.ConfigManager.get("app.export.path");
        service.exportAllToCsv(path);
        System.out.println("Exported to " + path);
    }
}
