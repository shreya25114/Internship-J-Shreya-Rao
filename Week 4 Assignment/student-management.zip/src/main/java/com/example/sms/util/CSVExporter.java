package com.example.sms.util;

import com.example.sms.model.Student;
import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CSVExporter {
    private static final DateTimeFormatter DF = DateTimeFormatter.ISO_LOCAL_DATE;

    public static void exportStudents(List<Student> students, String filepath) {
        File f = new File(filepath);
        f.getParentFile().mkdirs();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filepath))) {
            bw.write("id,firstName,lastName,email,dob,phone,gpa");
            bw.newLine();
            for (Student s : students) {
                String dob = s.getDob() == null ? "" : DF.format(s.getDob());
                bw.write(String.format("%s,%s,%s,%s,%s,%s,%s",
                        safe(s.getId()),
                        quote(s.getFirstName()),
                        quote(s.getLastName()),
                        quote(s.getEmail()),
                        dob,
                        quote(s.getPhone()),
                        safe(s.getGpa())
                ));
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to export CSV", e);
        }
    }

    private static String safe(Object o) { return o == null ? "" : o.toString(); }
    private static String quote(String s) { return s == null ? "" : s.replaceAll(""", """"); }
}
