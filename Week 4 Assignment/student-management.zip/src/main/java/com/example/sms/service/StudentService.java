package com.example.sms.service;

import com.example.sms.dao.StudentDao;
import com.example.sms.dao.impl.StudentDaoImpl;
import com.example.sms.exception.DaoException;
import com.example.sms.model.Student;
import com.example.sms.validation.StudentValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

public class StudentService {
    private static final Logger logger = LoggerFactory.getLogger(StudentService.class);
    private final StudentDao dao;

    public StudentService() { this.dao = new StudentDaoImpl(); }
    public StudentService(StudentDao dao) { this.dao = dao; }

    public Student createStudent(Student s) throws IllegalArgumentException, DaoException {
        List<String> errors = StudentValidator.validateForCreate(s);
        if (!errors.isEmpty()) {
            String msg = String.join("; ", errors);
            logger.warn("Validation failed for create: {}", msg);
            throw new IllegalArgumentException(msg);
        }
        Student created = dao.create(s);
        logger.info("Created student: {}", created);
        return created;
    }

    public Optional<Student> getStudentById(Long id) throws DaoException {
        StudentValidator.validateId(id).ifPresent(err -> { throw new IllegalArgumentException(err); });
        return dao.findById(id);
    }

    public List<Student> getAllStudents() throws DaoException {
        return dao.findAll();
    }

    public List<Student> searchByName(String q) throws DaoException {
        if (q == null) return Collections.emptyList();
        return dao.findByName(q).stream()
                .sorted(Comparator.comparing(Student::getLastName).thenComparing(Student::getFirstName))
                .collect(Collectors.toList());
    }

    public boolean updateStudent(Student s) throws DaoException {
        if (s.getId() == null) throw new IllegalArgumentException("Id required");
        List<String> errors = StudentValidator.validateForCreate(s);
        if (!errors.isEmpty()) throw new IllegalArgumentException(String.join(";", errors));
        boolean ok = dao.update(s);
        logger.info("Update student id={} success={}", s.getId(), ok);
        return ok;
    }

    public boolean deleteStudent(Long id) throws DaoException {
        StudentValidator.validateId(id).ifPresent(err -> { throw new IllegalArgumentException(err); });
        boolean ok = dao.delete(id);
        logger.info("Deleted student id={} result={}", id, ok);
        return ok;
    }

    public void exportAllToCsv(String path) throws DaoException {
        List<Student> all = dao.findAll();
        com.example.sms.util.CSVExporter.exportStudents(all, path);
        logger.info("Exported {} students to {}", all.size(), path);
    }
}
