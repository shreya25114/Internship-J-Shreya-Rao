package com.example.sms.validation;

import com.example.sms.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

public class StudentValidator {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    public static List<String> validateForCreate(Student s) {
        List<String> errors = new ArrayList<>();
        if (s.getFirstName() == null || s.getFirstName().trim().isEmpty()) errors.add("First name required");
        if (s.getLastName() == null || s.getLastName().trim().isEmpty()) errors.add("Last name required");
        if (s.getEmail() == null || !EMAIL.matcher(s.getEmail()).matches()) errors.add("Valid email required");
        if (s.getGpa() != null && (s.getGpa() < 0.0 || s.getGpa() > 10.0)) errors.add("GPA must be between 0 and 10");
        return errors;
    }

    public static Optional<String> validateId(Long id) {
        if (id == null || id <= 0) return Optional.of("Invalid id");
        return Optional.empty();
    }
}
