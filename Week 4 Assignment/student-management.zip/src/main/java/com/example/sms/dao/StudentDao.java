package com.example.sms.dao;

import com.example.sms.model.Student;
import com.example.sms.exception.DaoException;

import java.util.List;
import java.util.Optional;

public interface StudentDao {
    Student create(Student student) throws DaoException;
    Optional<Student> findById(Long id) throws DaoException;
    List<Student> findAll() throws DaoException;
    List<Student> findByName(String namePattern) throws DaoException;
    boolean update(Student student) throws DaoException;
    boolean delete(Long id) throws DaoException;
    long count() throws DaoException;
}
