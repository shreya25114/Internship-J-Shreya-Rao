package com.example.sms.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import javax.sql.DataSource;
import com.mysql.cj.jdbc.MysqlDataSource;

public class DBConnectionManager {
    private static final Logger logger = LoggerFactory.getLogger(DBConnectionManager.class);
    private static final DataSource dataSource;

    static {
        MysqlDataSource ds = new MysqlDataSource();
        ds.setURL(ConfigManager.get("db.url"));
        ds.setUser(ConfigManager.get("db.username"));
        ds.setPassword(ConfigManager.get("db.password"));
        dataSource = ds;
        logger.info("Initialized DataSource: {}", ConfigManager.get("db.url"));
    }

    private DBConnectionManager() {}

    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
}
