package com.example.sms.dao.impl;

import com.example.sms.dao.StudentDao;
import com.example.sms.model.Student;
import com.example.sms.util.DBConnectionManager;
import com.example.sms.exception.DaoException;

import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StudentDaoImpl implements StudentDao {
    private static final Logger logger = LoggerFactory.getLogger(StudentDaoImpl.class);

    private Student mapRow(ResultSet rs) throws SQLException {
        Student s = new Student();
        s.setId(rs.getLong("id"));
        s.setFirstName(rs.getString("first_name"));
        s.setLastName(rs.getString("last_name"));
        s.setEmail(rs.getString("email"));
        Date dob = rs.getDate("dob");
        if (dob != null) s.setDob(dob.toLocalDate());
        s.setPhone(rs.getString("phone"));
        Double gpa = rs.getDouble("gpa");
        if (!rs.wasNull()) s.setGpa(gpa);
        return s;
    }

    @Override
    public Student create(Student student) throws DaoException {
        String sql = "INSERT INTO students (first_name, last_name, email, dob, phone, gpa) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, student.getFirstName());
            ps.setString(2, student.getLastName());
            ps.setString(3, student.getEmail());
            if (student.getDob() != null) ps.setDate(4, Date.valueOf(student.getDob())); else ps.setNull(4, Types.DATE);
            ps.setString(5, student.getPhone());
            if (student.getGpa() != null) ps.setDouble(6, student.getGpa()); else ps.setNull(6, Types.DOUBLE);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new DaoException("Creating student failed, no rows affected.");
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) student.setId(keys.getLong(1));
            }
            return student;
        } catch (SQLException e) {
            logger.error("Error creating student", e);
            throw new DaoException(e);
        }
    }

    @Override
    public Optional<Student> findById(Long id) throws DaoException {
        String sql = "SELECT * FROM students WHERE id = ?";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
                return Optional.empty();
            }
        } catch (SQLException e) { throw new DaoException(e); }
    }

    @Override
    public List<Student> findAll() throws DaoException {
        String sql = "SELECT * FROM students";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Student> list = new ArrayList<>();
            while (rs.next()) list.add(mapRow(rs));
            return list;
        } catch (SQLException e) { throw new DaoException(e); }
    }

    @Override
    public List<Student> findByName(String namePattern) throws DaoException {
        String sql = "SELECT * FROM students WHERE first_name LIKE ? OR last_name LIKE ?";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + namePattern + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            try (ResultSet rs = ps.executeQuery()) {
                List<Student> list = new ArrayList<>();
                while (rs.next()) list.add(mapRow(rs));
                return list;
            }
        } catch (SQLException e) { throw new DaoException(e); }
    }

    @Override
    public boolean update(Student student) throws DaoException {
        if (student.getId() == null) throw new DaoException("Student id is null.");
        String sql = "UPDATE students SET first_name=?, last_name=?, email=?, dob=?, phone=?, gpa=? WHERE id=?";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, student.getFirstName());
            ps.setString(2, student.getLastName());
            ps.setString(3, student.getEmail());
            if (student.getDob() != null) ps.setDate(4, Date.valueOf(student.getDob())); else ps.setNull(4, Types.DATE);
            ps.setString(5, student.getPhone());
            if (student.getGpa() != null) ps.setDouble(6, student.getGpa()); else ps.setNull(6, Types.DOUBLE);
            ps.setLong(7, student.getId());
            int updated = ps.executeUpdate();
            return updated > 0;
        } catch (SQLException e) { throw new DaoException(e); }
    }

    @Override
    public boolean delete(Long id) throws DaoException {
        String sql = "DELETE FROM students WHERE id = ?";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { throw new DaoException(e); }
    }

    @Override
    public long count() throws DaoException {
        String sql = "SELECT COUNT(*) FROM students";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getLong(1);
        } catch (SQLException e) { throw new DaoException(e); }
    }
}
