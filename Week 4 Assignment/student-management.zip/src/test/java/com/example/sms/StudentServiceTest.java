package com.example.sms;

import com.example.sms.dao.StudentDao;
import com.example.sms.model.Student;
import com.example.sms.service.StudentService;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class StudentServiceTest {

    StudentDao mockDao;
    StudentService service;

    @BeforeEach
    void setup() {
        mockDao = mock(StudentDao.class);
        service = new StudentService(mockDao);
    }

    @Test
    void createStudent_success() throws Exception {
        Student input = new Student("John", "Doe", "john@example.com", null, null, 8.5);
        when(mockDao.create(any(Student.class))).thenAnswer(inv -> {
            Student s = inv.getArgument(0);
            s.setId(1L);
            return s;
        });

        Student created = service.createStudent(input);
        Assertions.assertNotNull(created.getId());
        verify(mockDao, times(1)).create(any(Student.class));
    }

    @Test
    void createStudent_validationFail() {
        Student bad = new Student("", "", "bademail", null, null, -1.0);
        Assertions.assertThrows(IllegalArgumentException.class, () -> service.createStudent(bad));
    }

    @Test
    void getStudentById_returns() throws Exception {
        Student s = new Student("Jane","Doe","jane@example.com", null, null, 9.0);
        s.setId(2L);
        when(mockDao.findById(2L)).thenReturn(Optional.of(s));
        Optional<Student> out = service.getStudentById(2L);
        Assertions.assertTrue(out.isPresent());
        Assertions.assertEquals("Jane", out.get().getFirstName());
    }

    @Test
    void deleteStudent_callsDao() throws Exception {
        when(mockDao.delete(3L)).thenReturn(true);
        boolean ok = service.deleteStudent(3L);
        Assertions.assertTrue(ok);
        verify(mockDao, times(1)).delete(3L);
    }

    @Test
    void searchByName_sorting() throws Exception {
        Student a = new Student("A","Zed","a@x.com", null, null, 8.0);
        Student b = new Student("B","Allen","b@x.com", null, null, 7.0);
        when(mockDao.findByName("a")).thenReturn(Arrays.asList(a,b));
        Assertions.assertEquals(2, service.searchByName("a").size());
    }
}
