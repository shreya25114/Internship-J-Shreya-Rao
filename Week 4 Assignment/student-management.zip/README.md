# Student Management System (Java 8 + JDBC)

## Requirements
- Java 8+, Maven, MySQL.

## Setup
1. Clone repo or unzip.
2. Create DB and table:
   - Use the provided SQL in `db/schema.sql` or run the commands in the README.
3. Configure DB credentials in `src/main/resources/application.properties`.
4. Build:
   mvn clean package
5. Run:
   java -jar target/student-management-1.0.0.jar
   (Or run `com.example.sms.Main` from your IDE.)

## Tests
mvn test

## Notes
- Uses PreparedStatements and try-with-resources.
- Logging via SLF4J + Logback.
- To use connection pooling, swap `DBConnectionManager` to HikariCP.
