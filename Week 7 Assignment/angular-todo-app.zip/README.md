# Angular Todo App
Placeholder project structure.