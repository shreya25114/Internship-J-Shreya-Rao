package com.example.studentmanagement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;

@Entity
@Table(name = "students")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Name must not be blank")
    private String name;

    @Min(value = 1, message = "Age must be positive")
    private int age;

    // Grade format examples: A, A+, B-, C
    @Pattern(regexp = "^[A-F](?:[+-])?$", message = "Grade must be like A, A+, B-, etc.")
    private String grade;

    private String address;
}
