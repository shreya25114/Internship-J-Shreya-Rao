package com.example.studentmanagement.service;

import com.example.studentmanagement.dto.StudentRequest;
import com.example.studentmanagement.dto.StudentResponse;
import com.example.studentmanagement.exception.ResourceNotFoundException;
import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;
    private final Logger logger = LoggerFactory.getLogger(StudentServiceImpl.class);

    private StudentResponse mapToResponse(Student s) {
        return StudentResponse.builder()
                .id(s.getId())
                .name(s.getName())
                .age(s.getAge())
                .grade(s.getGrade())
                .address(s.getAddress())
                .build();
    }

    @Override
    public StudentResponse addStudent(StudentRequest request) {
        Student s = Student.builder()
                .name(request.getName())
                .age(request.getAge())
                .grade(request.getGrade())
                .address(request.getAddress())
                .build();
        Student saved = studentRepository.save(s);
        logger.info("Added student with id={}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public List<StudentResponse> getAllStudents() {
        return studentRepository.findAll().stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    public StudentResponse getStudentById(Long id) {
        Student s = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
        return mapToResponse(s);
    }

    @Override
    public StudentResponse updateStudent(Long id, StudentRequest request) {
        Student s = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
        s.setName(request.getName());
        s.setAge(request.getAge());
        s.setGrade(request.getGrade());
        s.setAddress(request.getAddress());
        Student updated = studentRepository.save(s);
        logger.info("Updated student id={}", id);
        return mapToResponse(updated);
    }

    @Override
    public void deleteStudent(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new ResourceNotFoundException("Student not found with id: " + id);
        }
        studentRepository.deleteById(id);
        logger.info("Deleted student id={}", id);
    }
}
