package com.example.studentmanagement.service;

import com.example.studentmanagement.dto.StudentRequest;
import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StudentServiceImplTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentServiceImpl studentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addStudent_success() {
        StudentRequest req = StudentRequest.builder().name("John").age(20).grade("A").address("Addr").build();
        Student saved = Student.builder().id(1L).name("John").age(20).grade("A").address("Addr").build();
        when(studentRepository.save(any())).thenReturn(saved);

        var res = studentService.addStudent(req);

        assertNotNull(res);
        assertEquals(1L, res.getId());
        verify(studentRepository, times(1)).save(any());
    }
}
